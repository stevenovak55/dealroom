export { DocumentManager } from './DocumentManager';
