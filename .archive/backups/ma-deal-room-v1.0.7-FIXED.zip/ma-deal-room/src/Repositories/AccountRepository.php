<?php
/**
 * Account Repository
 *
 * @package MADealRoom\Repositories
 * @since 1.0.0
 */

namespace MADealRoom\Repositories;

use MADealRoom\Models\Account;

/**
 * Account repository
 */
class AccountRepository extends BaseRepository {
	/**
	 * Table name
	 *
	 * @var string
	 */	
	protected $table = 'ma_deal_accounts';

	/**
	 * Model class
	 *
	 * @var string
	 */
	protected $model_class = Account::class;

	/**
	 * Allowed columns for queries (SQL injection prevention)
	 *
	 * @var array
	 */
	protected $allowed_columns = [
		'id',
		'name',
		'owner_user_id',
		'status',
		'settings',
		'subscription_tier',
		'subscription_expires_at',
		'created_at',
		'updated_at'
	];

	/**
	 * Find an active account by owner user ID
	 *
	 * @param int $owner_user_id WordPress user ID of the account owner
	 * @return object|null Account model instance or null
	 */
	public function findByOwnerUserId(int $owner_user_id): ?object {
		$results = $this->query(
			['owner_user_id' => $owner_user_id, 'status' => 'active'],
			['limit' => 1]
		);

		return empty($results) ? null : $results[0];
	}

	/**
	 * Find the first active account
	 *
	 * @return object|null Account model instance or null
	 */
	public function findFirstActive(): ?object {
		$results = $this->query(
			['status' => 'active'],
			['limit' => 1]
		);

		return empty($results) ? null : $results[0];
	}
}