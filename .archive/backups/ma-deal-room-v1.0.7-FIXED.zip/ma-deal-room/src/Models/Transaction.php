<?php
/**
 * Transaction Model
 *
 * @package MADealRoom\Models
 * @since 1.0.0
 */

namespace MADealRoom\Models;

/**
 * Transaction model representing a property transaction
 */
class Transaction {
	public int $id;
	public int $account_id;
	public string $property_address;
	public string $property_city;
	public string $property_state = 'MA';
	public string $property_zip;
	public string $property_type; // SFH, Condo, Multifamily, Land, Commercial
	public ?int $property_year_built = null;
	public ?array $property_metadata = null;
	public ?float $sale_price = null;
	public string $transaction_side = 'listing'; // listing, buyer
	public string $transaction_type = 'buy_side'; // buy_side, sell_side, rental_landlord, rental_tenant, commercial_buy, commercial_sell
	public string $status = 'prospect'; // prospect, listing_active, under_agreement, closed, cancelled
	public ?string $listing_date = null;
	public ?string $offer_accepted_date = null;
	public ?string $ps_agreement_date = null;
	public ?string $loan_commitment_date = null;
	public ?string $closing_date = null;
	public ?string $actual_closing_date = null;
	public ?int $assigned_agent_id = null;
	public ?int $template_id = null;
	public ?string $notes = null;
	public string $created_at;
	public string $updated_at;

	/**
	 * Constructor
	 *
	 * @param array $data Initial data
	 */
	public function __construct(array $data = []) {
		foreach ($data as $key => $value) {
			if (property_exists($this, $key)) {
				// Handle JSON fields
				if ($key === 'property_metadata' && is_string($value)) {
					$this->$key = json_decode($value, true);
				} else {
					$this->$key = $value;
				}
			}
		}
	}

	/**
	 * Convert model to array
	 *
	 * @return array
	 */
	public function toArray(): array {
		$data = get_object_vars($this);

		// Convert metadata array to JSON string if needed
		if (isset($data['property_metadata']) && is_array($data['property_metadata'])) {
			$data['property_metadata'] = json_encode($data['property_metadata']);
		}

		// Add transaction_id as alias for id (for React compatibility)
		$data['transaction_id'] = $this->id;

		return $data;
	}

	/**
	 * Create instance from array
	 *
	 * @param array $data Data array
	 * @return self
	 */
	public static function fromArray(array $data): self {
		return new self($data);
	}

	/**
	 * Get valid transaction types
	 *
	 * @return array
	 */
	public static function getValidTransactionTypes(): array {
		return [
			'buy_side',
			'sell_side',
			'rental_landlord',
			'rental_tenant',
			'commercial_buy',
			'commercial_sell'
		];
	}

	/**
	 * Set transaction type with validation
	 *
	 * @param string $type Transaction type
	 * @throws \InvalidArgumentException If type is invalid
	 * @return void
	 */
	public function setTransactionType(string $type): void {
		if (!in_array($type, self::getValidTransactionTypes())) {
			throw new \InvalidArgumentException("Invalid transaction type: {$type}");
		}
		$this->transaction_type = $type;
	}

	/**
	 * Get transaction type
	 *
	 * @return string
	 */
	public function getTransactionType(): string {
		return $this->transaction_type;
	}

	/**
	 * Check if this is a buy-side transaction
	 *
	 * @return bool
	 */
	public function isBuySide(): bool {
		return $this->transaction_type === 'buy_side' || $this->transaction_type === 'commercial_buy';
	}

	/**
	 * Check if this is a sell-side transaction
	 *
	 * @return bool
	 */
	public function isSellSide(): bool {
		return $this->transaction_type === 'sell_side' || $this->transaction_type === 'commercial_sell';
	}

	/**
	 * Check if this is a rental transaction
	 *
	 * @return bool
	 */
	public function isRental(): bool {
		return $this->transaction_type === 'rental_landlord' || $this->transaction_type === 'rental_tenant';
	}

	/**
	 * Check if this involves property transfer (not rentals)
	 *
	 * @return bool
	 */
	public function involvesPropertyTransfer(): bool {
		return !$this->isRental();
	}
}
